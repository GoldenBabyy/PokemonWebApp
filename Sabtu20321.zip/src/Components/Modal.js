import React, {useState} from 'react';
import { Modal } from 'react-bootstrap';

export const PokemonModal = (props) => {
    const [nickname, setNickname] = useState('');

    const handleChange = (event)  => {
        setNickname(event.target.value);
    }

    const handleSubmit = () => {
        let arrNickname = JSON.parse(localStorage.getItem('nickname')) || [];
        let flagDuplicate = false;
        if(arrNickname.length > 0){
            arrNickname.forEach((name, index) => {
                console.log(name+ ' '+ nickname);
                if(name == nickname){
                    alert('ga bole msuk :p');
                    flagDuplicate=true;
                    return;
                }
            });
        }

        if(!flagDuplicate){
            arrNickname.push(nickname);
            localStorage.setItem('nickname', JSON.stringify(arrNickname));
        }
    }

    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">
                    Input Nickname
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <form>
                    <label>Nickname</label>
                    <input name='nickname' value={nickname} onChange={handleChange}></input>
                </form>
            </Modal.Body>
            <Modal.Footer>
                <button onClick={() => handleSubmit()}>Submit</button>
                <button onClick={() => props.onHide(false)}>Close</button>
            </Modal.Footer>
        </Modal>
    );
}