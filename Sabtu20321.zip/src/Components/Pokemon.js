import React from 'react';
import {NavLink, Link} from 'react-router-dom';

export const Pokemon = ({id, pokemonData}) => {
    const [isChangePage, setIsChangePage] = React.useState(false)
    const pokemonDetails = () => {
        setIsChangePage(true);
    };
  
    return(
        <div className="col-md-4">
            <Link to={{ pathname: "/pokemonDetail/" + pokemonData.name, state: pokemonData.image}} style={{textDecoration:'none'}}>
                <div className="card" onClick={pokemonDetails.bind(this,pokemonData.name)}>
                    <img className="img-fluid" src={pokemonData.image} alt={pokemonData.name} />
                    <div className="container card-body">
                        <h3>
                            {pokemonData.name}
                        </h3>
                    </div>
                </div>
            </Link>
        </div>
    )
}














        // <div className='pokemon'>
        //     <div className="pokemon__image">
        //         <img src={pokemonData.image} alt={pokemonData.name} />
        //     </div>
        //     <div className="pokemon__name">
        //         <strong>{pokemonData.name}</strong>
        //     </div>
        // </div>