import React from 'react';
import "../Styles/copyright.css"

export const Copyright = () => {
    return(
        <p className="copyright">© Ventryshia Andiyani - ventry.shiandiyani@gmail.com</p>
    )
}