import { Carousel } from 'react-bootstrap';
import React from 'react';

export const MoveCarousel= (props) => {
    
    const breakPoints = [
        { width: 1, itemsToShow: 1 },
        { width: 550, itemsToShow: 2, itemsToScroll: 2 },
        { width: 768, itemsToShow: 3 },
        { width: 1200, itemsToShow: 4 }
    ];

    return(
        <div className="App">
            <Carousel breakPoints={breakPoints}>
            {
                props.pokemonMoves.map((itemMove, id) => (
                    <Carousel.Item>
                        <p>{itemMove.move.name}</p>
                    </Carousel.Item>
                    )
                )
            }
            </Carousel>
        </div>
    )
}