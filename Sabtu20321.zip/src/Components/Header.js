import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav} from 'react-bootstrap';
import logo from '../Assets/logoPokemon.png';
import '../Styles/Header.css';

export const Header= () => {
    return(
        <>
            <Navbar bg="light" variant="light">
                <Navbar.Collapse id="responsive-navbar-nav" className='m-auto'>
                    <div className='animated bounce'>
                        <Nav.Link href='/' className='mb-0 justify-center align-center'>
                            <img
                                alt="Logo"
                                src={logo}
                                width="50"
                                className="d-inline-block float-left"
                            />
                            <h3 className='ml-5 mt-2 pl-3'>POKEMON</h3>
                        </Nav.Link>
                    </div>
                    <Nav.Link href='/MyPokemonList' className='ml-auto'>MyPokemon List</Nav.Link>
                    </Navbar.Collapse>
            </Navbar>
        </>
    )
}