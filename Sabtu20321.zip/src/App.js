import React from 'react';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import ApolloClient from 'apollo-boost';
import { ApolloProvider } from "@apollo/react-hooks";
import { Copyright } from './Components/Copyright';
import { Routes } from './Routes/routes';
// import './App.css';

function App() {
  const client = new ApolloClient({
    // uri: 'https://graphql-pokemon2.vercel.app/'
    uri: 'https://graphql-pokeapi.vercel.app/api/graphql'
  });

  return (
   <ApolloProvider client={client}>
      <BrowserRouter>
        <Routes />
    </BrowserRouter>
    <Copyright/>
   </ApolloProvider>
  );
}

export default App;


{/* <div className="App">
<header className="App-header">
  <img src={logo} className="App-logo" alt="logo" />
    <p>
      Edit <code>src/App.js</code> and save to reload.
    </p>
    <a
      className="App-link"
      href="https://reactjs.org"
      target="_blank"
      rel="noopener noreferrer">
      Learn React
    </a>
</header>
</div> */}