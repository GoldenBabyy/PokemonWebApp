import React from 'react';
import { useQuery } from '@apollo/react-hooks';
import { GetPokemonDetail } from '../GraphQL/GetPokemonDetail';
import { MoveCarousel } from '../Components/MoveCarousel';
import { PokemonModal } from '../Components/Modal';
import { Header } from '../Components/Header';
import '../Styles/PokemonDetail.css';

export const PokemonDetail = (props) => {
    const [isCatch, setIsCatch] = React.useState(false);
    const [isShow, setIsShow] = React.useState(false);

    const catchPokemon = () => {
        let rand = Math.random()*100;
        if(rand > 50){
            console.log('>50');    
            setIsCatch(true);
            setIsShow(true);
        }else{
            console.log('Ga ketangkep');
        }
    };

    const { loading, error, data} = useQuery(GetPokemonDetail, {
        variables: { name:props.match.params.name }
    });


    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error... :(</p>;

    console.log(data)
    console.log(props.location.state);
    console.log(props.match.params.name);
    return(
        <>
        <Header/>
        <div className='col-md-12 text-center'>
            <div className='divPokemon'>
                <img className="imgPokemon" src={props.location.state} alt={props.match.params.name}/>
                {/* <div className='button'> */}
                    <button className='btn-outline-success btn-catch' onClick={() => catchPokemon()}>Catch</button>
                {/* </div> */}
            </div>
            <div className='description'>
                <h1 className="pokemonName">{props.match.params.name}</h1>
                <div>
                {
                    data.pokemon.types.map(
                        (pokemon,id) => <h5>{pokemon.type.name}</h5>)
                }
                </div>
                <div>
                {
                    <MoveCarousel pokemonMoves={data.pokemon.moves}/>
                }
                </div>
                <div>
                    <PokemonModal
                        show={isShow}
                        onHide={setIsShow}
                    />
                </div>
            </div>
        </div>
        </>
    )

}