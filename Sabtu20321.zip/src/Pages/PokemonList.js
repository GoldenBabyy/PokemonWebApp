import React from 'react';
import { useQuery } from '@apollo/react-hooks';
import { GetPokemon } from '../GraphQL/GetPokemon';
import { Pokemon } from '../Components/Pokemon';
import { Header } from '../Components/Header';
import '../Styles/styleList.css';


export const PokemonList = () => {
    const { loading, error, data} = useQuery(GetPokemon, {
        variables: { limit: 9, offset: 0}
    });
    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error... :(</p>;

    return (
        <>
            <Header/>
            <div className='container col-md-10'>
                <div className='row'>
                    {data.pokemons.length == 0 ? 
                        ( 
                            <p className="text-white center"> No Pokemon Available</p> 
                        ) : ( 
                            data.pokemons.results.map(
                                (pokemon, id) => 
                                    <Pokemon id={id} key={id} pokemonData={pokemon} />
                            )
                        )
                    }
                </div>
            </div>
        </>
    )
}