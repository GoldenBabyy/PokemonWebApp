import React from 'react';

export const MyPokemonList = () => {
    return(
        <p>a</p>
    );
}