import React from 'react';

export const Index = () => {
    return (
        <p>a</p>
    )
}